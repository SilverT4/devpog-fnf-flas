This mod can be imported to the base mods folder of Psych Engine, or imported as its own folder. There are no songs in this folder, however, so unless you can figure out a way to load from a non-current mod directory, I suggest just extracting to `mods`.

Credits to the original creators of FNF: Soft. I only claim credit for the reskin. Rokusho and Medabots/Medarot are property of Imagineer.